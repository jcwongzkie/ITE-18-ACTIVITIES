import * as THREE from 'three'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js'

/**
 * Base
 */
// Canvas
const canvas = document.querySelector('canvas.webgl')

// Scene
const scene = new THREE.Scene()

// Objects
// 1) Box with subdivisions, rendered as wireframe
const boxGeometry = new THREE.BoxGeometry(1, 1, 1, 2, 2, 2)
const boxMaterial = new THREE.MeshBasicMaterial({ color: 0xff0000, wireframe: true })
const boxMesh = new THREE.Mesh(boxGeometry, boxMaterial)
boxMesh.position.x = -2
scene.add(boxMesh)

// 2) Sphere with more segments, rendered as wireframe
const sphereGeometry = new THREE.SphereGeometry(1, 32, 32)
const sphereMaterial = new THREE.MeshBasicMaterial({ color: 0xff0000, wireframe: true })
const sphereMesh = new THREE.Mesh(sphereGeometry, sphereMaterial)
scene.add(sphereMesh)

// 3) Custom BufferGeometry with random triangles
const trianglesCount = 50
const positionsArray = new Float32Array(trianglesCount * 3 * 3)
for(let i = 0; i < positionsArray.length; i++)
{
    positionsArray[i] = (Math.random() - 0.5) * 4
}
const positionsAttribute = new THREE.BufferAttribute(positionsArray, 3)
const randomGeometry = new THREE.BufferGeometry()
randomGeometry.setAttribute('position', positionsAttribute)
const randomMaterial = new THREE.MeshBasicMaterial({ color: 0xff0000, wireframe: true })
const randomMesh = new THREE.Mesh(randomGeometry, randomMaterial)
randomMesh.position.x = 2
scene.add(randomMesh)

// Sizes
const sizes = {
    width: window.innerWidth,
    height: window.innerHeight
}

window.addEventListener('resize', () =>
{
    // Update sizes
    sizes.width = window.innerWidth
    sizes.height = window.innerHeight

    // Update camera
    camera.aspect = sizes.width / sizes.height
    camera.updateProjectionMatrix()

    // Update renderer
    renderer.setSize(sizes.width, sizes.height)
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
})

// Camera
const camera = new THREE.PerspectiveCamera(75, sizes.width / sizes.height, 0.1, 100)
camera.position.z = 3
scene.add(camera)

// Controls
const controls = new OrbitControls(camera, canvas)
controls.enableDamping = true

// Renderer
const renderer = new THREE.WebGLRenderer({
    canvas: canvas
})
renderer.setSize(sizes.width, sizes.height)
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))

// Animate
const clock = new THREE.Clock()

const tick = () =>
{
    const elapsedTime = clock.getElapsedTime()

    // Update controls
    controls.update()

    // Render
    renderer.render(scene, camera)

    // Call tick again on the next frame
    window.requestAnimationFrame(tick)
}

tick()